import {
  collection, addDoc, getDocs, getDoc, doc, setDoc, updateDoc, deleteDoc,
  query, orderBy, where, serverTimestamp, increment, arrayUnion
} from "firebase/firestore";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile } from "firebase/auth";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage } from "./firebase";

export const PAYMENT_NUMBER = "01064788470";
const EMAIL_DOMAIN = "users.souq-el-baramoun.local";

export function normalizePhone(value = "") {
  const arabic = "٠١٢٣٤٥٦٧٨٩";
  const eastern = "۰۱۲۳۴۵۶۷۸۹";
  let s = String(value).trim();
  s = [...s].map(ch => {
    const a = arabic.indexOf(ch); if (a >= 0) return String(a);
    const e = eastern.indexOf(ch); if (e >= 0) return String(e);
    return ch;
  }).join("");
  s = s.replace(/[^0-9+]/g, "");
  if (s.startsWith("+20")) s = "0" + s.slice(3);
  if (s.startsWith("20") && s.length === 12) s = "0" + s.slice(2);
  return s;
}

function authEmail(phone) {
  return `${normalizePhone(phone)}@${EMAIL_DOMAIN}`;
}

export async function registerUser({ name, phone, password, role = "advertiser" }) {
  const normalized = normalizePhone(phone);
  if (!/^01[0125][0-9]{8}$/.test(normalized)) throw new Error("رقم الهاتف المصري غير صحيح");
  if (password.length < 6) throw new Error("كلمة المرور يجب ألا تقل عن 6 أحرف");
  const cred = await createUserWithEmailAndPassword(auth, authEmail(normalized), password);
  await updateProfile(cred.user, { displayName: name });
  await setDoc(doc(db, "users", cred.user.uid), {
    uid: cred.user.uid, name, phone: normalized, role,
    active: true, subscriptionStatus: role === "advertiser" ? "inactive" : "none",
    createdAt: serverTimestamp(), updatedAt: serverTimestamp()
  });
  return cred.user;
}

export async function loginUser(phone, password) {
  const cred = await signInWithEmailAndPassword(auth, authEmail(phone), password);
  return cred.user;
}

export async function logoutUser() { await signOut(auth); }

export async function updateUserProfile(uid, data) {
  if (!uid) throw new Error("المستخدم غير معروف");
  const safe = { ...data, updatedAt: serverTimestamp() };
  delete safe.role; delete safe.active; delete safe.subscriptionStatus; delete safe.subscriptionPlan;
  return updateDoc(doc(db, "users", uid), safe);
}

export async function fetchUsers() {
  const snap = await getDocs(query(collection(db, "users"), orderBy("createdAt", "desc")));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function setUserActive(uid, active) {
  return updateDoc(doc(db, "users", uid), { active: Boolean(active), updatedAt: serverTimestamp() });
}

export async function expireSubscriptions() {
  const snap = await getDocs(query(collection(db, "users"), where("subscriptionStatus", "==", "active")));
  const now = Date.now();
  const jobs = snap.docs.map(d => {
    const data = d.data();
    const exp = data.subscriptionExpiresAt ? new Date(data.subscriptionExpiresAt).getTime() : 0;
    if (exp && exp <= now) return updateDoc(d.ref, { subscriptionStatus: "expired", active: false, updatedAt: serverTimestamp() });
    return null;
  }).filter(Boolean);
  await Promise.all(jobs);
  return jobs.length;
}

export async function getUserProfile(uid) {
  const snap = await getDoc(doc(db, "users", uid));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function createAd(ad, files = []) {
  const user = auth.currentUser;
  if (!user) throw new Error("يجب تسجيل الدخول أولاً");
  const profile = await getUserProfile(user.uid);
  const imageUrls = [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const path = `ads/${user.uid}/${Date.now()}-${i}-${file.name.replace(/[^\w.\-]/g, "_")}`;
    const storageRef = ref(storage, path);
    await uploadBytes(storageRef, file, { contentType: file.type });
    imageUrls.push(await getDownloadURL(storageRef));
  }
  return addDoc(collection(db, "ads"), {
    title: ad.title.trim(), price: ad.price || "", category: ad.category,
    categoryName: ad.categoryName || "", city: ad.city.trim(), description: ad.description.trim(),
    images: imageUrls, image: imageUrls[0] || "", ownerId: user.uid,
    seller: profile?.name || user.displayName || "معلن", phone: profile?.phone || "",
    status: "pending", featured: false, featuredOrder: 999999, views: 0,
    createdAt: serverTimestamp(), updatedAt: serverTimestamp()
  });
}

export async function fetchAds(includePending = false) {
  const q = query(collection(db, "ads"), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(a => includePending || a.status === "approved");
}

export async function fetchFeaturedAds() {
  const q = query(collection(db, "ads"), where("status", "==", "approved"), where("featured", "==", true), orderBy("featuredOrder", "asc"));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function incrementAdViews(id) { return updateDoc(doc(db, "ads", id), { views: increment(1) }); }
export async function updateAd(id, data) { return updateDoc(doc(db, "ads", id), { ...data, updatedAt: serverTimestamp() }); }
export async function removeAd(id) { return deleteDoc(doc(db, "ads", id)); }

export async function createSubscriptionRequest({ plan, amount, transferReference, receiptFile }) {
  const user = auth.currentUser;
  if (!user) throw new Error("يجب تسجيل الدخول أولاً");
  let receiptUrl = "";
  if (receiptFile) {
    const path = `payment-receipts/${user.uid}/${Date.now()}-${receiptFile.name.replace(/[^\w.\-]/g, "_")}`;
    const storageRef = ref(storage, path);
    await uploadBytes(storageRef, receiptFile, { contentType: receiptFile.type });
    receiptUrl = await getDownloadURL(storageRef);
  }
  return addDoc(collection(db, "subscriptions"), {
    userId: user.uid, phone: (await getUserProfile(user.uid))?.phone || "",
    plan, amount: String(amount || ""), paymentMethod: "vodafone_cash",
    paymentNumber: PAYMENT_NUMBER, transferReference: transferReference || "",
    receiptUrl, status: "pending", createdAt: serverTimestamp(), updatedAt: serverTimestamp()
  });
}


export async function fetchMyAds(uid) {
  if (!uid) return [];
  const q = query(collection(db, "ads"), where("ownerId", "==", uid));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => (b.createdAt?.seconds||0) - (a.createdAt?.seconds||0));
}

export async function fetchSubscriptions() {
  const q = query(collection(db, "subscriptions"), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function updateSubscription(id, data) {
  return updateDoc(doc(db, "subscriptions", id), { ...data, updatedAt: serverTimestamp() });
}

export async function activateAdvertiser(userId, subscriptionId, plan) {
  const now = new Date();
  const months = plan === "ستة أشهر" ? 6 : plan === "ثلاثة أشهر" ? 3 : 1;
  const expiresAt = new Date(now);
  expiresAt.setMonth(expiresAt.getMonth() + months);
  await updateDoc(doc(db, "users", userId), {
    active: true, subscriptionStatus: "active", subscriptionPlan: plan,
    subscriptionStartedAt: serverTimestamp(), subscriptionExpiresAt: expiresAt.toISOString(), updatedAt: serverTimestamp()
  });
  if (subscriptionId) await updateSubscription(subscriptionId, { status: "approved", activatedAt: serverTimestamp(), expiresAt: expiresAt.toISOString() });
}

export async function rejectSubscription(id, note = "تم رفض طلب الاشتراك") {
  return updateSubscription(id, { status: "rejected", adminNote: note });
}


export async function fetchCategories() {
  const snap = await getDocs(query(collection(db, "categories"), orderBy("order", "asc")));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function saveCategory({ id, name, icon = "📦", order = 999 }) {
  const cleanName = String(name || "").trim();
  if (!cleanName) throw new Error("اسم الفئة مطلوب");
  const payload = { name: cleanName, icon, order: Number(order) || 999, updatedAt: serverTimestamp() };
  if (id) return updateDoc(doc(db, "categories", id), payload);
  return setDoc(doc(collection(db, "categories")), { ...payload, createdAt: serverTimestamp() });
}

export async function removeCategory(id) { return deleteDoc(doc(db, "categories", id)); }
export const deleteCategory = removeCategory;
export async function setFeaturedOrder(id, featuredOrder) { return updateDoc(doc(db, "ads", id), { featuredOrder: Number(featuredOrder), updatedAt: serverTimestamp() }); }

export async function createNotification({ userId = "all", title, body, type = "general" }) {
  return addDoc(collection(db, "notifications"), { userId, title: String(title || "إشعار"), body: String(body || ""), type, read: false, createdAt: serverTimestamp() });
}

export async function fetchNotifications(uid) {
  if (!uid) return [];
  const q = query(collection(db, "notifications"), where("userId", "in", [uid, "all"]));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));
}

export async function markNotificationRead(id) { return updateDoc(doc(db, "notifications", id), { read: true }); }

export async function notifyUser(userId, title, body, type = "general") { return createNotification({ userId, title, body, type }); }
